SFTP
====

.. automodule:: paramiko.sftp
.. automodule:: paramiko.sftp_client
.. automodule:: paramiko.sftp_server
.. automodule:: paramiko.sftp_attr
.. automodule:: paramiko.sftp_file
    :inherited-members:
    :no-special-members:
    :show-inheritance:
.. automodule:: paramiko.sftp_handle
.. automodule:: paramiko.sftp_si
