# last version component is odd for pre-release development, even for stable release
__version_info__ = (2, 7, 6)
__version__ = '.'.join(map(str, __version_info__))
