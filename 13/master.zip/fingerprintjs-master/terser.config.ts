// Note: this file is non standard, it's imported explicitly
// Reference: https://github.com/terser/terser
export default {
  format: {
    comments: false,
  },
  safari10: true,
}
