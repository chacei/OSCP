export default function isPdfViewerEnabled(): boolean | undefined {
  return navigator.pdfViewerEnabled
}
